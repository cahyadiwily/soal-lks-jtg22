<?php

/**
 * Class Forminator_Addon_Hubspot_Exception
 * Not Required but encouraged
 *
 * @since 1.0 HubSpot Addon
 */
class Forminator_Addon_Hubspot_Exception extends Exception {

}
