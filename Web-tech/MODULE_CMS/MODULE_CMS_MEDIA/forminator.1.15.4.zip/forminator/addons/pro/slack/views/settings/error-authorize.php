<?php
// defaults
$vars = array(
	'auth_url'      => '',
	'error_message' => '',
);
/** @var array $template_vars */
foreach ( $template_vars as $key => $val ) {
	$vars[ $key ] = $val;
}
?>
<div class="integration-header">
	<h3 class="sui-box-title" id="dialogTitle2">
		<?php
		/* translators: ... */
		echo esc_html( sprintf( __( 'Failed to add %1$s', 'forminator' ), 'Slack' ) );
		?>
	</h3>
	<p>
		<?php if ( ! empty( $vars['error_message'] ) ) : ?>
			<?php echo esc_html( $vars['error_message'] ); ?>
		<?php endif; ?>
	</p>
</div>
<div class="sui-block-content-center">
	<a href="<?php echo esc_attr( $vars['auth_url'] ); ?>" target="_blank" class="sui-button forminator-addon-connect"><?php esc_html_e( 'Retry', 'forminator' ); ?></a>
</div>
