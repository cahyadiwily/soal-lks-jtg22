<div class="integration-header">

	<h3 id="dialogTitle2" class="sui-box-title">
		<?php
			/* translators: ... */
			echo esc_html( sprintf( __( '%1$s Added', 'forminator' ), 'Campaign Monitor' ) );
		?>
	</h3>

	<span class="sui-description" style="margin-top: 20px;"><?php esc_html_e( 'You can now go to your forms and assign them to this integration', 'forminator' ); ?></span>

</div>
