<?php

/**
 * Class Forminator_Addon_Trello_Wp_Api_Exception
 * Exception holder for Trello wp api
 *
 * @since 1.0 Trello Addon
 */
class Forminator_Addon_Trello_Wp_Api_Exception extends Forminator_Addon_Trello_Exception {
}
