<?php

/**
 * Class Forminator_Addon_Mailchimp_Wp_Api_Exception
 * Exception holder for mailchimp wp api
 *
 * @since 1.0 Mailchimp Addon
 */
class Forminator_Addon_Mailchimp_Wp_Api_Exception extends Forminator_Addon_Mailchimp_Exception {
}
