# Forminator UI

For internal use in [WPMU DEV](https://wpmudev.org/) plugins.

### Usage

See our [showcase](https://wpmudev.github.io/forminator-ui/).

### Contributing

Please read through our [contributing guidelines](https://github.com/wpmudev/forminator-ui/blob/development/CONTRIBUTING.md).

**Remember:** Pull Requests will be approved **only** if have their changes listed on `CHANGELOG.md` file.