export default class FrontCalculatorParserNodeAbstract {
	constructor() {
	}
}
